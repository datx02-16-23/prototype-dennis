/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

import java.util.Arrays;

/**
 *
 * @author dennis
 */
public class WriteFrom extends Operation{
    private String fromId;
    private int[] fromIndex;
    public static final String OPERATION = "write from";

    public WriteFrom(String id, int[] index, String[] values) {
        super(id, OPERATION, index, values);
    }
    
    public WriteFrom(String id, int[] index, String[] values, String fromId, int[] fromIndex) {
        this(id, index, values);
        this.fromId = fromId;
        this.fromIndex = fromIndex;
        
    }
    
    

    @Override
    public String toString() {
        return "{"+super.toString()+", \"from id\":\""+fromId+"\", \"from index\":"+Arrays.toString(fromIndex)+"}";
    }   
}
