package com.dennisjonsson.annotation;


import javax.lang.model.type.TypeMirror;

public class DataStructure{
	
	public String name;
	public DataStructureType DSType;
	public TypeMirror type;
	
	
	public DataStructure(){
		
	}
	
	public DataStructure(String name, DataStructureType DSType, TypeMirror type){
		this.name = name;
		this.DSType = DSType;
		this.type = type;
	}
	
}