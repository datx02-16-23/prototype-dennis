/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author dennis
 */
public class Body {
    public ArrayList<Operation> operations;

    public Body() {
        this.operations = new ArrayList<Operation>();
    }
    
    public void appendOperation(Operation op){
        operations.add(op);
    }
    
    @Override
    public String toString() {
        return  Arrays.toString(this.operations.toArray());
    }
    
}
