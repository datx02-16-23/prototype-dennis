/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 *
 * @author dennis
 */
public class Header {
    public HashMap<String, DataStructure> variables;
    private String visual;
    private ArrayList<Integer> size ;

    public Header() {
        this.variables = new HashMap<String, DataStructure> ();
        this.size = new ArrayList<Integer>();
    }
    
    public void addDataStructure(DataStructure dataStructure){
        this.variables.put( dataStructure.getName(),dataStructure);
    }

 
    public void setVisual(String visual) {
        this.visual = visual;
    }
    
    public void updateSize(String name, int ... index){
        variables.get(name).updateSize(index);
    }
 
    @Override
    public String toString() {
        return "{\n \"variables\": "+Arrays.toString(variables.values().toArray())+", \n"
              + "\"visual\": \""+this.visual+"\"\n"
              + "}";
    }
    
    
    
}
