package com.dennisjonsson.annotation;

public enum DataStructureType{
	ARRAY,
        ADJECENCY_MATRIX,
        ADJECENCY_LIST,
	LIST,
	TREE
}