/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

/**
 *
 * @author dennis
 */
public class Markup {
    
    public Header header;
    public Body body;

    public Markup(Header header) {
        this.header = header;
        this.body = new Body();
    }
    
    public void appendDataStructure(DataStructure dataStructure){
        this.header.addDataStructure(dataStructure);
    }
    
    public void updateSize(String name, int ... index){
        header.updateSize(name, index);
    }
 
    public void appendOperation(Operation op){
        this.body.appendOperation(op);
        updateSize(op.getId(), op.getIndex());
    }

    @Override
    public String toString() {
        return "{\n \"header\":" + header.toString() + ",\n "
                + "\"body\":" + body.toString() + "\n}";
    }
     
}
