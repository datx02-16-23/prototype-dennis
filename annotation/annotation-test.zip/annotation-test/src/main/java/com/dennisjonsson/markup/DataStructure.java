/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author dennis
 */
public class DataStructure {
    
    private String type;
    private String name;
    private ArrayList<Integer> size;

    public DataStructure(String type, String name) {
        this.type = type;
        this.name = name;
        this.size = new ArrayList<Integer>();
    }

    public String getType() {
        return type;
    }

    public void setType(DataStructureType type) {
        this.type = type.toString();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void updateSize(int ... index){
        
        for(int i = 0; i < index.length; i ++){
            if(size.size() <= i){
                size.add(index[i]+1);
            }else{
                size.set(i, Math.max(index[i]+1, size.get(i)));
            }
        }
        
    }

    @Override
    public String toString() {
        return "{\"name\": \""+this.name+"\","
                + " \"type\": \""+this.type+"\","
                + " \"size\": "+Arrays.toString(this.size.toArray())+"}";
    }
    
    
    
       
       
}
