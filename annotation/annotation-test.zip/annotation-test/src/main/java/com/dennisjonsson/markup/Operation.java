/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

import java.util.Arrays;

/**
 *
 * @author dennis
 */
public class Operation {
    
    private String id;
    private String op;
    private int [] index;
    private String [] values;
    

    public Operation(String id,String op ,int[] index, String[] values) {
        this.id = id;
        this.op = op;
        this.index = index;
        this.values = values;
        
    }
    
    public void extendIndex(int in){
        int[] newIndex = new int[index.length + 1];
        for(int i = 0; i < index.length; i++){
            newIndex[i] = index[i];
        }
        newIndex[index.length] = in;
        index = newIndex;
    }

    public int[] getIndex() {
        return index;
    }

    public String getId() {
        return id;
    }
    

    @Override
    public String toString() {
        return   "\"id\": \""+id+"\", "
                + "\"op\": \""+op+"\","
                + " \"index\": "+Arrays.toString(this.index)+","
                + " \"value\": "+printStringArray(this.values);
                
    }
    
    public String printStringArray(String [] array){
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        for(int i = 0; i < array.length; i++){
            builder.append("\""+array[i]+"\",");
        }
        if(array.length > 0){
            builder.deleteCharAt(builder.length()- 1);
        }
        builder.append("]");
        return builder.toString();
        
    }
    
  
    
    
    
}
