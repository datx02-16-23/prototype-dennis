/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

/**
 *
 * @author dennis
 */
public class Read extends Operation{
    
    public static final String OPERATION = "read";
    public Read(String id, int[] index, String[] values) {
        super(id, OPERATION, index, values);
    }

    @Override
    public String toString() {
        return "{"+super.toString()+"}";
    }
    
    
    
}
