/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.datx.scenario2.sorting;

import com.dennisjonsson.annotation.VisualClass;
import com.dennisjonsson.annotation.Visualize;
import java.util.Arrays;


@VisualClass
public class MergeSort 
{
 
    
    public static int[] sort(@Visualize(abstractType="array")int[] list) 
    {
        //If list is empty; no need to do anything
        if (list.length <= 1) {
            return list;
        }
         
        //Split the array in half in two parts
        int[] first = new int[list.length / 2];
        int[] second = new int[list.length - first.length];
        
        first = Arrays.copyOfRange(list, 0, first.length);
        second = Arrays.copyOfRange(list, first.length, first.length + second.length);
        
        if(first.length <= 5 || second.length  <= 5){
            QuickSort.sort(first);
            QuickSort.sort(second);
        }else{
            sort(first);
            sort(second);
        }
        //Merge both halves together, overwriting to original array
        merge(first, second, list);
        return list;
    }
     
    private static void merge(@Visualize(abstractType="array")int[] first, 
            @Visualize(abstractType="array")int[] second, 
            @Visualize(abstractType="array")int[] result) 
    {
        //Index Position in first array - starting with first element
        int iFirst = 0;
         
        //Index Position in second array - starting with first element
        int iSecond = 0;
         
        //Index Position in merged array - starting with first position
        int iMerged = 0;
         
        //Compare elements at iFirst and iSecond, 
        //and move smaller element at iMerged
        while (iFirst < first.length && iSecond < second.length) 
        {
            if (first[iFirst] < second[iSecond]) 
            {
                result[iMerged] = first[iFirst];
                iFirst++;
            } 
            else
            {
                result[iMerged] = second[iSecond];
                iSecond++;
            }
            iMerged++;
        }
        
     
        // arraycopy(Object src, int srcPos, Object dest, int destPos, int length)
        
        //copy remaining elements from both halves - each half will have already sorted elements
       System.arraycopy(first, iFirst, result, iMerged, first.length - iFirst);
       System.arraycopy(second, iSecond, result, iMerged, second.length - iSecond);
    }
    
 
}
