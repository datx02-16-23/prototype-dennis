/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.datx.scenario3;

import com.dennisjonsson.annotation.VisualClass;
import com.dennisjonsson.annotation.Visualize;

/**
 *
 * @author dennis
 */

public class KnapSackVisual{
public static com.dennisjonsson.annotation.log.ast.ASTLogger logger = 
com.dennisjonsson.annotation.log.ast.ASTLogger.instance(new com.dennisjonsson.annotation.log.ast.SourceHeader("KnapSackVisual",new String [] { "/*"," * To change this license header, choose License Headers in Project Properties."," * To change this template file, choose Tools | Templates"," * and open the template in the editor."," */","package edu.datx.scenario3;","","import com.dennisjonsson.annotation.VisualClass;","import com.dennisjonsson.annotation.Visualize;","","/**"," *"," * @author dennis"," */","@VisualClass","public class KnapSack {","","    public int w;","","    @Visualize(abstractType = 'matrix')","    int[][] mem;","","    @Visualize(abstractType = 'array')","    int[] array;","","    int n = -1;","","    public  KnapSack(int w) {","        this.w = w;","    }","","    public int[][] fillSack(int[] array) {","        int n = array.length;","        this.array = array;","        mem = new int[n][this.w];","        initilize();","        knap(n - 1, w - 1);","        return mem;","    }","","    private int knap(int i, int wc) {","        if (i == 0 || wc <= 0) {","            return 0;","        }","        if (mem[i][wc] == -1) {","            if (wc < array[i]) {","                mem[i][wc] = knap(i - 1, wc);","            } else {","                mem[i][wc] = Math.max(knap(i, wc - array[i]) + array[i], knap(i - 1, wc));","            }","        }","        return mem[i][wc];","    }","","    private void initilize() {","        for (int i = 0; i < mem.length; i++) {","            for (int j = 0; j < mem[i].length; j++) {","                mem[i][j] = -1;","            }","        }","    }","}"},"",new com.dennisjonsson.annotation.markup.DataStructure [] {  com.dennisjonsson.annotation.markup.DataStructureFactory.getDataStructure("matrix","int[][]","edu.datx.scenario3.KnapSack mem"),com.dennisjonsson.annotation.markup.DataStructureFactory.getDataStructure("array","int[]","edu.datx.scenario3.KnapSack array")},new edu.datx.interpreter.MyInterpreter(),"C:UsersdennisDocumentsNetBeansProjectsUsertest1"));

    public int w;

    
    int[][] mem;

    
    int[] array;

    int n = -1;

    public  KnapSackVisual(int w) {
        this.w = w;
    }

    public int[][] fillSack(int[] array) {
        int n = array.length;
        eval("edu.datx.scenario3.KnapSack array", this.array = write("array", array, 1, 1), 0, new int[] { 31, 31 });
        eval("edu.datx.scenario3.KnapSack mem", mem = write(null, new int[n][this.w], 3, 1), 0, new int[] { 32, 32 });
        initilize();
        knap(n - 1, w - 1);
        return mem;
    }

    private int knap(int i, int wc) {
        if (i == 0 || wc <= 0) {
            return 0;
        }
        if (eval(null, mem[read("edu.datx.scenario3.KnapSack mem", 0, i)], 2, new int[] { 42, 42 })[wc] == -1) {
            if (wc < eval(null, array[read("edu.datx.scenario3.KnapSack array", 0, i)], 2, new int[] { 43, 43 })) {
                eval("edu.datx.scenario3.KnapSack mem", mem[read("edu.datx.scenario3.KnapSack mem", 0, i)][read("edu.datx.scenario3.KnapSack mem", 1, wc)] = write(null, knap(i - 1, wc), 3, 0), 0, new int[] { 44, 44 });
            } else {
                eval("edu.datx.scenario3.KnapSack mem", mem[read("edu.datx.scenario3.KnapSack mem", 0, i)][read("edu.datx.scenario3.KnapSack mem", 1, wc)] = write(null, Math.max(knap(i, wc - eval(null, array[read("edu.datx.scenario3.KnapSack array", 0, i)], 2, new int[] { 47, 47 })) + eval(null, array[read("edu.datx.scenario3.KnapSack array", 0, i)], 2, new int[] { 47, 47 }), knap(i - 1, wc)), 3, 0), 0, new int[] { 46, 47 });
            }
        }
        return eval(null, mem[read("edu.datx.scenario3.KnapSack mem", 0, i)][read("edu.datx.scenario3.KnapSack mem", 1, wc)], 2, new int[] { 50, 50 });
    }

    private void initilize() {
        for (int i = 0; i < mem.length; i++) {
            for (int j = 0; j < eval(null, mem[read("edu.datx.scenario3.KnapSack mem", 0, i)], 2, new int[] { 55, 55 }).length; j++) {
                eval("edu.datx.scenario3.KnapSack mem", mem[read("edu.datx.scenario3.KnapSack mem", 0, i)][read("edu.datx.scenario3.KnapSack mem", 1, j)] = write(null, -1, 3, 0), 0, new int[] { 56, 56 });
            }
        }
    }

public static int eval( String targetId, int value, int expressionType, int [] line){
logger.eval("KnapSackVisual", targetId, value, expressionType, line);
return value;
}
public static int write(String name, int value, int sourceType, int targetType ){
logger.write("KnapSackVisual", name, value, sourceType, targetType);
return value;
}
public static int[] eval( String targetId, int[] value, int expressionType, int [] line){
logger.eval("KnapSackVisual", targetId, java.util.Arrays.copyOf(value,value.length), expressionType, line);
return value;
}
public static int[] write(String name, int[] value, int sourceType, int targetType ){
logger.write("KnapSackVisual", name, java.util.Arrays.copyOf(value,value.length), sourceType, targetType);
return value;
}
public static int[][] eval( String targetId, int[][] value, int expressionType, int [] line){
logger.eval("KnapSackVisual", targetId, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][]>().deepCopy(value), expressionType, line);
return value;
}
public static int[][] write(String name, int[][] value, int sourceType, int targetType ){
logger.write("KnapSackVisual", name, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][]>().deepCopy(value), sourceType, targetType);
return value;
}
public static int[][][] eval( String targetId, int[][][] value, int expressionType, int [] line){
logger.eval("KnapSackVisual", targetId, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][][]>().deepCopy(value), expressionType, line);
return value;
}
public static int[][][] write(String name, int[][][] value, int sourceType, int targetType ){
logger.write("KnapSackVisual", name, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][][]>().deepCopy(value), sourceType, targetType);
return value;
}
public static int read(String name,int dimension, int index ){ 
logger.read("KnapSackVisual", name ,index ,dimension);
return index; 
}
}
