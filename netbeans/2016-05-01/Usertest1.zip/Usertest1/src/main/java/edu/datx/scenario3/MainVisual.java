/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.datx.scenario3;

import com.dennisjonsson.annotation.VisualClass;

/**
 *
 * @author dennis
 */

public class MainVisual{
public static com.dennisjonsson.annotation.log.ast.ASTLogger logger = 
com.dennisjonsson.annotation.log.ast.ASTLogger.instance(new com.dennisjonsson.annotation.log.ast.SourceHeader("MainVisual",new String [] { "/*"," * To change this license header, choose License Headers in Project Properties."," * To change this template file, choose Tools | Templates"," * and open the template in the editor."," */","package edu.datx.scenario3;","","import com.dennisjonsson.annotation.VisualClass;","","/**"," *"," * @author dennis"," */","@VisualClass","public class Main {","","    /**","     * @param args the command line arguments","     */","    public static void main(String[] args) {","        KnapSack sack = new KnapSack(20);","        sack.fillSack(new int[] { 4, 5, 1, 2, 8, 6, 3, 5, 4 });","    }","}"},"",new com.dennisjonsson.annotation.markup.DataStructure [] { },new edu.datx.interpreter.MyInterpreter(),"C:UsersdennisDocumentsNetBeansProjectsUsertest1"));

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        edu.datx.scenario3.KnapSackVisual sack = new edu.datx.scenario3.KnapSackVisual(20);
        sack.fillSack(new int[] { 4, 5, 1, 2, 8, 6, 3, 5, 4 });
    }
public static int read(String name,int dimension, int index ){ 
logger.read("MainVisual", name ,index ,dimension);
return index; 
}
}
