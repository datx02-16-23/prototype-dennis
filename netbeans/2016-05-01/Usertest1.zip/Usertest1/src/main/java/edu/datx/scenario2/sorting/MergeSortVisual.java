/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.datx.scenario2.sorting;

import com.dennisjonsson.annotation.VisualClass;
import com.dennisjonsson.annotation.Visualize;
import java.util.Arrays;


public class MergeSortVisual{
public static com.dennisjonsson.annotation.log.ast.ASTLogger logger = 
com.dennisjonsson.annotation.log.ast.ASTLogger.instance(new com.dennisjonsson.annotation.log.ast.SourceHeader("MergeSortVisual",new String [] { "/*"," * To change this license header, choose License Headers in Project Properties."," * To change this template file, choose Tools | Templates"," * and open the template in the editor."," */","package edu.datx.scenario2.sorting;","","import com.dennisjonsson.annotation.VisualClass;","import com.dennisjonsson.annotation.Visualize;","import java.util.Arrays;","","@VisualClass","public class MergeSort {","","    public static int[] sort(@Visualize(abstractType = 'array') int[] list) {","        //If list is empty; no need to do anything","        if (list.length <= 1) {","            return list;","        }","        //Split the array in half in two parts","        int[] first = new int[list.length / 2];","        int[] second = new int[list.length - first.length];","        first = Arrays.copyOfRange(list, 0, first.length);","        second = Arrays.copyOfRange(list, first.length, first.length + second.length);","        if (first.length <= 5 || second.length <= 5) {","            QuickSort.sort(first);","            QuickSort.sort(second);","        } else {","            sort(first);","            sort(second);","        }","        //Merge both halves together, overwriting to original array","        merge(first, second, list);","        return list;","    }","","    private static void merge(@Visualize(abstractType = 'array') int[] first, @Visualize(abstractType = 'array') int[] second, @Visualize(abstractType = 'array') int[] result) {","        //Index Position in first array - starting with first element","        int iFirst = 0;","        //Index Position in second array - starting with first element","        int iSecond = 0;","        //Index Position in merged array - starting with first position","        int iMerged = 0;","        //and move smaller element at iMerged","        while (iFirst < first.length && iSecond < second.length) {","            if (first[iFirst] < second[iSecond]) {","                result[iMerged] = first[iFirst];","                iFirst++;","            } else {","                result[iMerged] = second[iSecond];","                iSecond++;","            }","            iMerged++;","        }","        // arraycopy(Object src, int srcPos, Object dest, int destPos, int length)","        //copy remaining elements from both halves - each half will have already sorted elements","        System.arraycopy(first, iFirst, result, iMerged, first.length - iFirst);","        System.arraycopy(second, iSecond, result, iMerged, second.length - iSecond);","    }","}"},"",new com.dennisjonsson.annotation.markup.DataStructure [] {  com.dennisjonsson.annotation.markup.DataStructureFactory.getDataStructure("array","int[]","edu.datx.scenario2.sorting.MergeSort sort list"),com.dennisjonsson.annotation.markup.DataStructureFactory.getDataStructure("array","int[]","edu.datx.scenario2.sorting.MergeSort merge first"),com.dennisjonsson.annotation.markup.DataStructureFactory.getDataStructure("array","int[]","edu.datx.scenario2.sorting.MergeSort merge second"),com.dennisjonsson.annotation.markup.DataStructureFactory.getDataStructure("array","int[]","edu.datx.scenario2.sorting.MergeSort merge result")},new edu.datx.interpreter.MyInterpreter(),"C:UsersdennisDocumentsNetBeansProjectsUsertest1"));

    public static int[] sort( int[] list) {
        //If list is empty; no need to do anything
        if (list.length <= 1) {
            return list;
        }
        //Split the array in half in two parts
        int[] first = new int[list.length / 2];
        int[] second = new int[list.length - first.length];
        first = Arrays.copyOfRange(list, 0, first.length);
        second = Arrays.copyOfRange(list, first.length, first.length + second.length);
        if (first.length <= 5 || second.length <= 5) {
            edu.datx.scenario2.sorting.QuickSortVisual.sort(eval("edu.datx.scenario2.sorting.MergeSort sort list", write(null, first, 3, 1), 3, new int[] { 33, 33 }));
            edu.datx.scenario2.sorting.QuickSortVisual.sort(eval("edu.datx.scenario2.sorting.MergeSort sort list", write(null, second, 3, 1), 3, new int[] { 34, 34 }));
        } else {
            sort(eval("edu.datx.scenario2.sorting.MergeSort sort list", write(null, first, 3, 1), 3, new int[] { 36, 36 }));
            sort(eval("edu.datx.scenario2.sorting.MergeSort sort list", write(null, second, 3, 1), 3, new int[] { 37, 37 }));
        }
        //Merge both halves together, overwriting to original array
        merge(eval("edu.datx.scenario2.sorting.MergeSort merge first", write(null, first, 3, 1), 3, new int[] { 40, 40 }), eval("edu.datx.scenario2.sorting.MergeSort merge second", write(null, second, 3, 1), 3, new int[] { 40, 40 }), eval("edu.datx.scenario2.sorting.MergeSort merge result", write("edu.datx.scenario2.sorting.MergeSort sort list", list, 1, 1), 3, new int[] { 40, 40 }));
        return list;
    }

    private static void merge( int[] first,  int[] second,  int[] result) {
        //Index Position in first array - starting with first element
        int iFirst = 0;
        //Index Position in second array - starting with first element
        int iSecond = 0;
        //Index Position in merged array - starting with first position
        int iMerged = 0;
        //and move smaller element at iMerged
        while (iFirst < first.length && iSecond < second.length) {
            if (eval(null, first[read("edu.datx.scenario2.sorting.MergeSort merge first", 0, iFirst)], 2, new int[] { 61, 61 }) < eval(null, second[read("edu.datx.scenario2.sorting.MergeSort merge second", 0, iSecond)], 2, new int[] { 61, 61 })) {
                eval("edu.datx.scenario2.sorting.MergeSort merge result", result[read("edu.datx.scenario2.sorting.MergeSort merge result", 0, iMerged)] = write("edu.datx.scenario2.sorting.MergeSort merge first", first[read("edu.datx.scenario2.sorting.MergeSort merge first", 0, iFirst)], 0, 0), 0, new int[] { 63, 63 });
                iFirst++;
            } else {
                eval("edu.datx.scenario2.sorting.MergeSort merge result", result[read("edu.datx.scenario2.sorting.MergeSort merge result", 0, iMerged)] = write("edu.datx.scenario2.sorting.MergeSort merge second", second[read("edu.datx.scenario2.sorting.MergeSort merge second", 0, iSecond)], 0, 0), 0, new int[] { 68, 68 });
                iSecond++;
            }
            iMerged++;
        }
        // arraycopy(Object src, int srcPos, Object dest, int destPos, int length)
        //copy remaining elements from both halves - each half will have already sorted elements
        System.arraycopy(first, iFirst, result, iMerged, first.length - iFirst);
        System.arraycopy(second, iSecond, result, iMerged, second.length - iSecond);
    }

public static int eval( String targetId, int value, int expressionType, int [] line){
logger.eval("MergeSortVisual", targetId, value, expressionType, line);
return value;
}
public static int write(String name, int value, int sourceType, int targetType ){
logger.write("MergeSortVisual", name, value, sourceType, targetType);
return value;
}
public static int[] eval( String targetId, int[] value, int expressionType, int [] line){
logger.eval("MergeSortVisual", targetId, java.util.Arrays.copyOf(value,value.length), expressionType, line);
return value;
}
public static int[] write(String name, int[] value, int sourceType, int targetType ){
logger.write("MergeSortVisual", name, java.util.Arrays.copyOf(value,value.length), sourceType, targetType);
return value;
}
public static int[][] eval( String targetId, int[][] value, int expressionType, int [] line){
logger.eval("MergeSortVisual", targetId, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][]>().deepCopy(value), expressionType, line);
return value;
}
public static int[][] write(String name, int[][] value, int sourceType, int targetType ){
logger.write("MergeSortVisual", name, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][]>().deepCopy(value), sourceType, targetType);
return value;
}
public static int read(String name,int dimension, int index ){ 
logger.read("MergeSortVisual", name ,index ,dimension);
return index; 
}
}
