/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.datx.scenario3;

import com.dennisjonsson.annotation.VisualClass;
import com.dennisjonsson.annotation.Visualize;

/**
 *
 * @author dennis
 */
@VisualClass
public class KnapSack {
    
    public int w;
    @Visualize(abstractType = "matrix")
    int [][] mem;
    @Visualize(abstractType = "array")
    int [] array;
    int n = -1;

    public KnapSack(int w) {
        this.w = w;
    }
    
    public int [][] fillSack(int [] array){
        int n = array.length;
        this.array = array;
        mem = new int[n][this.w];
        initilize();
        knap(n - 1, w-1);
        return mem;
    }
    
    private int knap(int i, int wc){
        if( i == 0 || wc <= 0){
            return 0;
        }
        if(mem[i][wc] == -1){
            if(wc < array[i]){
                mem[i][wc] = knap(i-1, wc);
            }else{
                mem[i][wc] = Math.max(
                        knap(i, wc - array[i]) + array[i], knap(i-1, wc));
            }
        }
        return mem[i][wc];
    }
    
    private void initilize(){
        for(int i =0; i < mem.length; i++){
            for(int j =0; j < mem[i].length; j++){
                mem[i][j] = -1;
            }
        }
    }
   
    
    
    
}
