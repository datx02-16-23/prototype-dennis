/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.datx.temp;

/*
@SourcePath(path="C:/Users/user/projects/my_project")
@VisualClass*/
public class MyClass {
    /*
    @Visualize(abstractType="array")
    public static int [] array;
    
    public static void main(String[] args) {
        array = new int[]{2,3,1};
        foo(array);
    } 
    
    public static void foo(@Visualize(abstractType="array") int [] a){
        // do something
    }*/
}
