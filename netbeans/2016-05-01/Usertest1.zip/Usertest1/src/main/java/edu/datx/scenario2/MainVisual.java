package edu.datx.scenario2;

import com.dennisjonsson.annotation.SourcePath;
import com.dennisjonsson.annotation.VisualClass;
import com.dennisjonsson.annotation.Visualize;
import edu.datx.scenario2.sorting.MergeSort;
import java.util.Arrays;


public class MainVisual{
public static com.dennisjonsson.annotation.log.ast.ASTLogger logger = 
com.dennisjonsson.annotation.log.ast.ASTLogger.instance(new com.dennisjonsson.annotation.log.ast.SourceHeader("MainVisual",new String [] { "package edu.datx.scenario2;","","import com.dennisjonsson.annotation.SourcePath;","import com.dennisjonsson.annotation.VisualClass;","import com.dennisjonsson.annotation.Visualize;","import edu.datx.scenario2.sorting.MergeSort;","import java.util.Arrays;","","@VisualClass","public class Main {","","    @Visualize(abstractType = 'array')","    static int[] a = new int[] { 3, 18, 9, 6, 5, 14, 1, 2, 4, 7, 8, 9, 6, 5, 11, 4, 9, 20 };","","    public static void main(String[] args) {","        MergeSort.sort(a);","        a = a;","        System.out.println(Arrays.toString(a));","    }","}"},"",new com.dennisjonsson.annotation.markup.DataStructure [] {  com.dennisjonsson.annotation.markup.DataStructureFactory.getDataStructure("array","int[]","edu.datx.scenario2.Main a")},new edu.datx.interpreter.MyInterpreter(),"C:UsersdennisDocumentsNetBeansProjectsUsertest1"));

    
    static int[] a = eval("edu.datx.scenario2.Main a", write(null, new int[] { 3, 18, 9, 6, 5, 14, 1, 2, 4, 7, 8, 9, 6, 5, 11, 4, 9, 20 }, 3, 1), 0, new int[] { 22, 22 });

    public static void main(String[] args) {
        edu.datx.scenario2.sorting.MergeSortVisual.sort(a);
        eval("edu.datx.scenario2.Main a", a = write("edu.datx.scenario2.Main a", a, 1, 1), 0, new int[] { 27, 27 });
        System.out.println(Arrays.toString(a));
    }

public static int eval( String targetId, int value, int expressionType, int [] line){
logger.eval("MainVisual", targetId, value, expressionType, line);
return value;
}
public static int write(String name, int value, int sourceType, int targetType ){
logger.write("MainVisual", name, value, sourceType, targetType);
return value;
}
public static int[] eval( String targetId, int[] value, int expressionType, int [] line){
logger.eval("MainVisual", targetId, java.util.Arrays.copyOf(value,value.length), expressionType, line);
return value;
}
public static int[] write(String name, int[] value, int sourceType, int targetType ){
logger.write("MainVisual", name, java.util.Arrays.copyOf(value,value.length), sourceType, targetType);
return value;
}
public static int[][] eval( String targetId, int[][] value, int expressionType, int [] line){
logger.eval("MainVisual", targetId, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][]>().deepCopy(value), expressionType, line);
return value;
}
public static int[][] write(String name, int[][] value, int sourceType, int targetType ){
logger.write("MainVisual", name, new com.dennisjonsson.annotation.log.ast.LogUtils<int[][]>().deepCopy(value), sourceType, targetType);
return value;
}
public static int read(String name,int dimension, int index ){ 
logger.read("MainVisual", name ,index ,dimension);
return index; 
}
}
