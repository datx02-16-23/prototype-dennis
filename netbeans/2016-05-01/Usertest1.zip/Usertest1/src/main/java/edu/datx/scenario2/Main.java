
package edu.datx.scenario2;

import com.dennisjonsson.annotation.SourcePath;
import com.dennisjonsson.annotation.VisualClass;
import com.dennisjonsson.annotation.Visualize;
import edu.datx.scenario2.sorting.MergeSort;
import java.util.Arrays;

/*
    check this out:
    http://stackoverflow.com/questions/22494596/eclipse-annotation-processor-get-project-path

    See if you can interate through the file tree from a file location.
*/


@VisualClass
public class Main {

    @Visualize(abstractType = "array")
    static int [] a = new int [] {3,18,9,6,5,14,1,2,4,7,8,9,6,5,11,4,9,20};
    
    public static void main(String[] args) {
        
        MergeSort.sort(a);
        a = a;
        System.out.println(Arrays.toString(a));
    }
    
}
