/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.datx.scenario3;

import com.dennisjonsson.annotation.VisualClass;

/**
 *
 * @author dennis
 */
@VisualClass
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        KnapSack sack = new KnapSack(20);
        sack.fillSack(new int [] {4,5,1,2,8,6,3,5,4});
    }
    
}
