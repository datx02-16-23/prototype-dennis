/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.visualization.test.app;

import com.dennisjonsson.annotation.VisualClass;
import com.dennisjonsson.visualization.test.BFSTestArray;

/**
 *
 * @author dennis
 */
@VisualClass
public class SynchTest {
    
   public static int[][] a = new int[][] { { 3, 1, 2,1 }, { 3, 0, 2,0 }, { 1, 3, 0,1 }, { 1, 2, 0,0 } };

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BFSTestArray bfs = new BFSTestArray();
        bfs.bfs(a, 0);
        
        
    }
    
}
