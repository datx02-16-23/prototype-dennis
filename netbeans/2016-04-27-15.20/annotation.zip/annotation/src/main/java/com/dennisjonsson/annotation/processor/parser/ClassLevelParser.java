/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.annotation.processor.parser;

import com.dennisjonsson.annotation.markup.DataStructure;
import com.dennisjonsson.annotation.markup.Method;
import static com.dennisjonsson.annotation.processor.parser.MainParser.PRINT_METHOD;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.visitor.ModifierVisitorAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import javax.lang.model.element.Element;

/**
 *
 * @author dennis
 */
public class ClassLevelParser extends Parser {
    
    MainParser parser;

    public ClassLevelParser(
            String className, 
            String fullClassName, 
            ArrayList<DataStructure> dataStruct, 
            Element printMethod, 
            HashMap<String, Method> methods) {
        
        super(className, fullClassName, dataStruct, printMethod, methods);
        parser = new MainParser(this);
        
    }

    @Override
    public Node visit(FieldDeclaration n, Object arg) {
        parser.visit(n, new ASTArgument());
        return super.visit(n, arg); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public Node visit(MethodDeclaration n, Object arg) {
        
        setPrintMethod(n);
        parseMethodBody(n, arg);
        return super.visit(n, arg); 
    }
    
    private void parseMethodBody(MethodDeclaration n, Object arg){
        parser.setMethodScope(n.getName());
        parser.visit(n, new ASTArgument());
        parser.setMethodScope(null);
        
    }
    
    private void setPrintMethod(MethodDeclaration n){
        
        if(printMethod == null){
            return; 
        }
        
        String name = n.getName();
        String print = printMethod.toString().replaceAll("\\(.*\\)", "");
        //System.out.println(name + ", "+print);
        if(name.equalsIgnoreCase(print)){
            ArrayList<Expression> args = new ArrayList<>();
            n.getBody().getStmts().add(new ExpressionStmt (new MethodCallExpr(null, PRINT_METHOD, args)));
        }
    }
    
}
