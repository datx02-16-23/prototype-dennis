package com.dennisjonsson.visualization.test;



import com.dennisjonsson.annotation.VisualClassPath;
import com.dennisjonsson.annotation.Visualize;
import com.dennisjonsson.markup.AbstractType;
import java.util.*;



public class PrioQueueVisual{
public static com.dennisjonsson.log.Logger logger = 
new com.dennisjonsson.log.Logger(
new String [] {"ARRAY","java.lang.Object[]","array"});
	
	interface Comparator{
		int compare(Object elm1, Object elm2);
	}

	private Comparator comparator;

	// Underlying array for storing all elements in heap
        
	private Object[] array;
	// Starting capacity of the array
	private static final int DEFAULT_CAPACITY = 2;
	// Keeps track of the number of elements in the array.
	private int currentSize;

    
  	public PrioQueueVisual(Comparator comparator){
	      	
		array = new Object[DEFAULT_CAPACITY+1];
		currentSize = 0;
		this.comparator = comparator;
   	 }

	public PrioQueueVisual(Comparator comparator, Object [] Array){
		array = Array;
		currentSize = Array.length;
		this.comparator = comparator;
		buildHeap();
   	 }

	/*
		resets the queue to a previous size
	*/
	public void reset(int size){
		if(eval("6855cd76-8e2b-4e1e-b652-6c92861a1f1c", array[read("array",
"6855cd76-8e2b-4e1e-b652-6c92861a1f1c",
0,size-1)],0) != null){
			currentSize = size;
			buildHeap();
		}
	}

	/*
		removes all from a certain index
	*/
	public void decrease(int size){
		int oldSize = currentSize;
		currentSize = currentSize-size;
		for(int i = currentSize; i < oldSize; i++){
			eval("38f1b936-8ccd-4240-8e29-278ecec62567", array[read("array",
"38f1b936-8ccd-4240-8e29-278ecec62567",
0,i)] = 
write("array", "38f1b936-8ccd-4240-8e29-278ecec62567",null),logger.endStatement());
		}

		
	}


	private void buildHeap(){
		for (int k = size()/2; k > 0; k--){
			shiftDown(k);
		}
	}
    
	/**
	* 
	* @return first element in heap
	*/
    
    	public void clear(){
	    	array = new Object[DEFAULT_CAPACITY+1];
	    	currentSize = 0;
   	}
    
    	public Object top(){
		if(currentSize <= 0)
		    throw new RuntimeException("not possible");
		return (Object)eval("81bcdf04-1d50-41d4-addd-2b2778708d56", array[read("array",
"81bcdf04-1d50-41d4-addd-2b2778708d56",
0,0)],logger.endStatement());
   	}
   	 
    	public Object bottom(){
	    	if(size() <= 0)
	    		throw new RuntimeException("not possible, size too small");
	    	return (Object)eval("b88fa840-0425-4a0d-aaa3-32c0de214337", array[read("array",
"b88fa840-0425-4a0d-aaa3-32c0de214337",
0,size() - 1)],logger.endStatement());
    	}

	public Object[] toArray(){
		Object [] arr = new Object[currentSize];
		System.arraycopy(array,0,arr,0,currentSize);
		return arr;
	}

	public Object[] getSorted(){

		Object [] arr = new Object [currentSize];
		int index = 0;
		while(size() > 0){
			arr[index] = remove();
			index ++;
		}
		return arr;
		
	}

	/**
	* Inserts an new object into the heap
	 * Time complexity is O(log n), O(n) when it needs to be extended.
	* @param x object to inserted
	*/
    	public void add(Object x){
	
		//assert invariant() : showHeap();
		
		if(currentSize + 1 > array.length )
		    doubleArray();
		eval("0a7fd7c8-449c-4335-881b-31796759363f", array[read("array",
"0a7fd7c8-449c-4335-881b-31796759363f",
0,currentSize)] = 
write("array", "0a7fd7c8-449c-4335-881b-31796759363f",x),logger.endStatement());
		int index = shiftUp(currentSize);
		currentSize++;
		
		//assert invariant() : showHeap();
    	}
    
	/**
	* removes smallest element in heap
	 * Time complexity is O(log n)
	* @return smallest element in heap
	*/
    	public Object remove(){
		if(currentSize <= 0){
		    throw new RuntimeException("Cannot remove from an empty heap!");
		}
		//assert invariant() : showHeap();	
		// move last element to the top
       	        currentSize --;
		Object firstElm = (Object)eval("a43afa96-9719-4fe5-af8a-7dfcee705a48", array[read("array",
"a43afa96-9719-4fe5-af8a-7dfcee705a48",
0,0)],logger.endStatement());
		Object lastElm = (Object)eval("707579a5-32c5-47bd-a77f-79a577b78895", array[read("array",
"707579a5-32c5-47bd-a77f-79a577b78895",
0,currentSize)],logger.endStatement());
		// tweak
		eval("081d1416-5592-4072-aa96-e3a024e365ce", array[read("array",
"081d1416-5592-4072-aa96-e3a024e365ce",
0,currentSize)] = 
write("array", "081d1416-5592-4072-aa96-e3a024e365ce",firstElm),logger.endStatement());
	
		if(currentSize > 0){
			eval("6a5ff5c5-3756-4ab5-a993-3600a297d66a", array[read("array",
"6a5ff5c5-3756-4ab5-a993-3600a297d66a",
0,0)] = 
write("array", "6a5ff5c5-3756-4ab5-a993-3600a297d66a",lastElm),logger.endStatement());
			int index = shiftDown(0);
		}
		//assert invariant() : showHeap();
		return firstElm;
    	}
    
	/**
	* Internal method for shifting an element down the heap
	 * Time complexity is O(log n)
	* @param index starting index
	* @return final index
	*/
   	 private int shiftDown(int index){
	    	Object x = eval("25c6a6f4-1906-4fda-8b9f-ae59c8d95c05", array[read("array",
"25c6a6f4-1906-4fda-8b9f-ae59c8d95c05",
0,index)],logger.endStatement());
		int child;
		while(index*2 + 1 <currentSize){
		    child = index*2 + 1;
		    if(child + 1 < currentSize && 
		            comparator.compare(eval("89aa1ea7-183d-44bd-91d6-2539ca652dc0", array[read("array",
"89aa1ea7-183d-44bd-91d6-2539ca652dc0",
0,child)],0),eval("556e8a80-9f7b-420a-b126-e782acd5ce59", array[read("array",
"556e8a80-9f7b-420a-b126-e782acd5ce59",
0,child+1)],0))>0){
		        child++;
		    }if(comparator.compare(x,eval("dc2cd674-5238-43ab-8baf-fc79a2e704bc", array[read("array",
"dc2cd674-5238-43ab-8baf-fc79a2e704bc",
0,child)],0))>0){
		        eval("60f1ce1a-3d88-426e-8b52-fac6752de485", array[read("array",
"60f1ce1a-3d88-426e-8b52-fac6752de485",
0,index)] = 
write("array", "60f1ce1a-3d88-426e-8b52-fac6752de485",(Object)eval("60f1ce1a-3d88-426e-8b52-fac6752de485", array[read("array",
"60f1ce1a-3d88-426e-8b52-fac6752de485",
0,child)],0)),logger.endStatement());
		        index = child;
		    }else
		        break;
		}
		eval("e7fcc9ee-10a1-4561-9b1d-e58df64b33f3", array[read("array",
"e7fcc9ee-10a1-4561-9b1d-e58df64b33f3",
0,index)] = 
write("array", "e7fcc9ee-10a1-4561-9b1d-e58df64b33f3",x),logger.endStatement());
		return index;
  	  }
    
	/**
	* Internal method for shifting an element up the heap
	 * Time complexity is O(log n) (worst case)
	* @param index starting index
	* @return final index where the element ended up
	*/
    	private int shiftUp(int index){
		int parent;
		Object x = eval("e924e333-f314-474c-ab41-676e07b77f6b", array[read("array",
"e924e333-f314-474c-ab41-676e07b77f6b",
0,index)],logger.endStatement());
		while(index>0){
		    if(index%2==0)
		        parent = (index-2)/2;
		    else
		        parent = (index - 1)/2;
		    
		    if(parent>=0 && 
		            comparator.compare(x,eval("dfa1e5da-8ad1-43a0-8dfa-fdbcd31bb760", array[read("array",
"dfa1e5da-8ad1-43a0-8dfa-fdbcd31bb760",
0,parent)],0))<0){
		        eval("151bdecb-5cac-4746-bb76-00421dd6721a", array[read("array",
"151bdecb-5cac-4746-bb76-00421dd6721a",
0,index)] = 
write("array", "151bdecb-5cac-4746-bb76-00421dd6721a",(Object)eval("151bdecb-5cac-4746-bb76-00421dd6721a", array[read("array",
"151bdecb-5cac-4746-bb76-00421dd6721a",
0,parent)],0)),logger.endStatement());
				
		        index = parent;
		    }else
		        break;
		}
		eval("39c63dac-a606-4741-8b84-54dcc43c6e8b", array[read("array",
"39c63dac-a606-4741-8b84-54dcc43c6e8b",
0,index)] = 
write("array", "39c63dac-a606-4741-8b84-54dcc43c6e8b",x),logger.endStatement());
		return index;
    	}
    
	/**
	* Internal method for extending the array when it is full
	 * Time complexity is O(n)
	*/
    	private void doubleArray(){
	    	Object[] newArray = new Object[array.length * 2];
		for( int i = 0; i < array.length; i++ )
		    newArray[i] = eval("bf792431-9f2d-4a18-ad24-9998852f22c0", array[read("array",
"bf792431-9f2d-4a18-ad24-9998852f22c0",
0,i)],logger.endStatement());
		array = newArray;
    	}
    
    	public int size(){
      	  return currentSize;
    	}

	@Override
	public String toString() {
		String str = "";
		for(int i =0; i < currentSize; i++){
		    str += eval("72f275e3-5698-4979-8c7b-04949cd47b53", array[read("array",
"72f275e3-5698-4979-8c7b-04949cd47b53",
0,i)],0).toString();
		    if(i<currentSize - 1)
		        str += ", ";
		}
		
		return str;
    	}
	
	/*
		INVARIANT
		looks through the heap recursively before and after add, 
		remove and update makes any changes the heap
	*/
    
	/**
	* Internal method for checking the heap order invariant
	* Looks through the heap starting from the root
	*/
	private boolean invariant(){
		return lookThroughHeap(0);
	}
	
	/**
	* Internal method used by the invariant.
	* Recursively looks through the heap, starting from a given index
	* @param index index to start from
	* @return true if the heap order is kept below the given node index
	*/
	public boolean lookThroughHeap(int index){
		int child = index * 2 + 1;
		if(child < currentSize){
			if(!checkChildren(index,child))
				return false;
			else{
				child ++;
				if(child < currentSize)
					return checkChildren(index,child);
				else
					return true;
			}
		}else
			return true;
		
	}
	
	/**
	* Internal method used by the invariant
	* Compares a given child against its parent.
	* If the heap order is kept, it continues checking the heap order below the child.
	* @param parent index of parent
	* @param child index of child
	* @return true if the heap order is kept below the parent
	*/
	private boolean checkChildren(int parent, int child){
		if(comparator.compare(eval("b9c3ec10-9c45-4018-931b-cfc1942a08de", array[read("array",
"b9c3ec10-9c45-4018-931b-cfc1942a08de",
0,parent)],0),eval("87b304c2-abae-41a9-a390-ae3ab394b2c2", array[read("array",
"87b304c2-abae-41a9-a390-ae3ab394b2c2",
0,child)],0)) <= 0)
			return lookThroughHeap(child);
		else
			return false;
	}

	/**
	* Internal method used by the invariant.
	* prints out the heap.
	*/
	private String showHeap(){
			// TODO: return description of heap contents.
			return toString();
	}
        
        public static void main(String [] args){
            Integer [] integers = new Integer[20];
            for(int i = 0; i < integers.length; i++){
                integers[i] = (int)(Math.random()* 100);
            }
            PrioQueueVisual p = new PrioQueueVisual(new Comparator(){
                @Override
                public int compare(Object elm1, Object elm2) {
                    Integer i1 = (Integer)elm1;
                    Integer i2 = (Integer)elm2;
                    if(i1 < i2){
                        return -1;
                    }
                    if(i1 > i2){
                        return 1;
                    }
                    return 0;
                }
            
            },
            integers);
            
            
logger.printLog();

        }
        
        

public static int read(String name,String statementId, int dimension, int index){ 
logger.loggRead(name, statementId ,index ,dimension);
return index; 
}
public static java.lang.Object write(String name, String statementId, java.lang.Object value){
logger.logWrite(name, statementId, value+"");
return value;
}
public static int eval(String statementId, int value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static String eval(String statementId, String value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static boolean eval(String statementId, boolean value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static char eval(String statementId, char value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static double eval(String statementId, double value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static float eval(String statementId, float value, int statement){
logger.logEval(statementId, value+"");
return value;
}

public static java.lang.Object eval(String statementId, java.lang.Object value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static java.lang.Object[] eval(String statementId, java.lang.Object[] value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static java.lang.Object[][] eval(String statementId, java.lang.Object[][] value, int statement){
logger.logEval(statementId, value+"");
return value;
}
}
