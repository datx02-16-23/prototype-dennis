package com.dennisjonsson.visualization.test;



import com.dennisjonsson.annotation.VisualClassPath;
import com.dennisjonsson.annotation.Visualize;
import com.dennisjonsson.markup.AbstractType;
import java.util.*;



public class PrioQueueVisual{
public static com.dennisjonsson.log.Logger logger = 
new com.dennisjonsson.log.Logger(
new String [] {"ARRAY","java.lang.Object[]","array"});
	
	interface Comparator{
		int compare(Object elm1, Object elm2);
	}

	private Comparator comparator;

	// Underlying array for storing all elements in heap
        
	private Object[] array;
	// Starting capacity of the array
	private static final int DEFAULT_CAPACITY = 2;
	// Keeps track of the number of elements in the array.
	private int currentSize;

    
  	public PrioQueueVisual(Comparator comparator){
	      	
		array = new Object[DEFAULT_CAPACITY+1];
		currentSize = 0;
		this.comparator = comparator;
   	 }

	public PrioQueueVisual(Comparator comparator, Object [] Array){
		array = Array;
		currentSize = Array.length;
		this.comparator = comparator;
		buildHeap();
   	 }

	/*
		resets the queue to a previous size
	*/
	public void reset(int size){
		if(eval("a29ac597-1e1f-4620-827a-bf6efc913e5a", array[read("array",
"a29ac597-1e1f-4620-827a-bf6efc913e5a",
0,size-1)],0) != null){
			currentSize = size;
			buildHeap();
		}
	}

	/*
		removes all from a certain index
	*/
	public void decrease(int size){
		int oldSize = currentSize;
		currentSize = currentSize-size;
		for(int i = currentSize; i < oldSize; i++){
			eval("8a51725b-b609-460d-9512-92b768d393af", array[read("array",
"8a51725b-b609-460d-9512-92b768d393af",
0,i)] = 
write("array", "8a51725b-b609-460d-9512-92b768d393af",null),logger.endStatement());
		}

		
	}


	private void buildHeap(){
		for (int k = size()/2; k > 0; k--){
			shiftDown(k);
		}
	}
    
	/**
	* 
	* @return first element in heap
	*/
    
    	public void clear(){
	    	array = new Object[DEFAULT_CAPACITY+1];
	    	currentSize = 0;
   	}
    
    	public Object top(){
		if(currentSize <= 0)
		    throw new RuntimeException("not possible");
		return (Object)eval("2a960db6-4180-494c-b284-46a37bd7f49a", array[read("array",
"2a960db6-4180-494c-b284-46a37bd7f49a",
0,0)],logger.endStatement());
   	}
   	 
    	public Object bottom(){
	    	if(size() <= 0)
	    		throw new RuntimeException("not possible, size too small");
	    	return (Object)eval("05758ae8-ced9-4d37-8ee3-c82eb580c807", array[read("array",
"05758ae8-ced9-4d37-8ee3-c82eb580c807",
0,size() - 1)],logger.endStatement());
    	}

	public Object[] toArray(){
		Object [] arr = new Object[currentSize];
		System.arraycopy(array,0,arr,0,currentSize);
		return arr;
	}

	public Object[] getSorted(){

		Object [] arr = new Object [currentSize];
		int index = 0;
		while(size() > 0){
			arr[index] = remove();
			index ++;
		}
		return arr;
		
	}

	/**
	* Inserts an new object into the heap
	 * Time complexity is O(log n), O(n) when it needs to be extended.
	* @param x object to inserted
	*/
    	public void add(Object x){
	
		//assert invariant() : showHeap();
		
		if(currentSize + 1 > array.length )
		    doubleArray();
		eval("944c75e9-9951-4c45-92bd-20aed36cddc1", array[read("array",
"944c75e9-9951-4c45-92bd-20aed36cddc1",
0,currentSize)] = 
write("array", "944c75e9-9951-4c45-92bd-20aed36cddc1",x),logger.endStatement());
		int index = shiftUp(currentSize);
		currentSize++;
		
		//assert invariant() : showHeap();
    	}
    
	/**
	* removes smallest element in heap
	 * Time complexity is O(log n)
	* @return smallest element in heap
	*/
    	public Object remove(){
		if(currentSize <= 0){
		    throw new RuntimeException("Cannot remove from an empty heap!");
		}
		//assert invariant() : showHeap();	
		// move last element to the top
       	        currentSize --;
		Object firstElm = (Object)eval("4d7ce508-cae2-4f5b-8bbd-430a28d1e0ac", array[read("array",
"4d7ce508-cae2-4f5b-8bbd-430a28d1e0ac",
0,0)],logger.endStatement());
		Object lastElm = (Object)eval("bd1aa710-ea9e-4808-8a53-cb7345bd6a0f", array[read("array",
"bd1aa710-ea9e-4808-8a53-cb7345bd6a0f",
0,currentSize)],logger.endStatement());
		// tweak
		eval("60f046e4-1f5c-42ca-8599-9af0567c6a3a", array[read("array",
"60f046e4-1f5c-42ca-8599-9af0567c6a3a",
0,currentSize)] = 
write("array", "60f046e4-1f5c-42ca-8599-9af0567c6a3a",firstElm),logger.endStatement());
	
		if(currentSize > 0){
			eval("d264fa43-796e-4059-91dc-20de30873614", array[read("array",
"d264fa43-796e-4059-91dc-20de30873614",
0,0)] = 
write("array", "d264fa43-796e-4059-91dc-20de30873614",lastElm),logger.endStatement());
			int index = shiftDown(0);
		}
		//assert invariant() : showHeap();
		return firstElm;
    	}
    
	/**
	* Internal method for shifting an element down the heap
	 * Time complexity is O(log n)
	* @param index starting index
	* @return final index
	*/
   	 private int shiftDown(int index){
	    	Object x = eval("41486598-5c90-48d1-8ca5-abae58addf22", array[read("array",
"41486598-5c90-48d1-8ca5-abae58addf22",
0,index)],logger.endStatement());
		int child;
		while(index*2 + 1 <currentSize){
		    child = index*2 + 1;
		    if(child + 1 < currentSize && 
		            comparator.compare(eval("88b62c56-4b3e-4d33-a44e-0b3b9373138e", array[read("array",
"88b62c56-4b3e-4d33-a44e-0b3b9373138e",
0,child)],0),eval("ea467fb0-dee9-4439-b05f-7903dd8e6008", array[read("array",
"ea467fb0-dee9-4439-b05f-7903dd8e6008",
0,child+1)],0))>0){
		        child++;
		    }if(comparator.compare(x,eval("1a21acd8-7d91-45fe-b2da-8d427a6990cb", array[read("array",
"1a21acd8-7d91-45fe-b2da-8d427a6990cb",
0,child)],0))>0){
		        eval("63f5bb95-efa2-4cef-9a67-458b3cdb03df", array[read("array",
"63f5bb95-efa2-4cef-9a67-458b3cdb03df",
0,index)] = 
write("array", "63f5bb95-efa2-4cef-9a67-458b3cdb03df",(Object)eval("63f5bb95-efa2-4cef-9a67-458b3cdb03df", array[read("array",
"63f5bb95-efa2-4cef-9a67-458b3cdb03df",
0,child)],0)),logger.endStatement());
		        index = child;
		    }else
		        break;
		}
		eval("93b51ff6-0a54-41b5-84e6-78bffd88372b", array[read("array",
"93b51ff6-0a54-41b5-84e6-78bffd88372b",
0,index)] = 
write("array", "93b51ff6-0a54-41b5-84e6-78bffd88372b",x),logger.endStatement());
		return index;
  	  }
    
	/**
	* Internal method for shifting an element up the heap
	 * Time complexity is O(log n) (worst case)
	* @param index starting index
	* @return final index where the element ended up
	*/
    	private int shiftUp(int index){
		int parent;
		Object x = eval("e4a03bd3-a89d-42a4-8985-47ddbca09663", array[read("array",
"e4a03bd3-a89d-42a4-8985-47ddbca09663",
0,index)],logger.endStatement());
		while(index>0){
		    if(index%2==0)
		        parent = (index-2)/2;
		    else
		        parent = (index - 1)/2;
		    
		    if(parent>=0 && 
		            comparator.compare(x,eval("de093d35-f890-4e7d-a14c-53c44ab7dd6b", array[read("array",
"de093d35-f890-4e7d-a14c-53c44ab7dd6b",
0,parent)],0))<0){
		        eval("b9919d0d-bf96-4812-9bc8-1bf03b576c31", array[read("array",
"b9919d0d-bf96-4812-9bc8-1bf03b576c31",
0,index)] = 
write("array", "b9919d0d-bf96-4812-9bc8-1bf03b576c31",(Object)eval("b9919d0d-bf96-4812-9bc8-1bf03b576c31", array[read("array",
"b9919d0d-bf96-4812-9bc8-1bf03b576c31",
0,parent)],0)),logger.endStatement());
				
		        index = parent;
		    }else
		        break;
		}
		eval("6e411268-d380-483f-8a09-d70f0af87820", array[read("array",
"6e411268-d380-483f-8a09-d70f0af87820",
0,index)] = 
write("array", "6e411268-d380-483f-8a09-d70f0af87820",x),logger.endStatement());
		return index;
    	}
    
	/**
	* Internal method for extending the array when it is full
	 * Time complexity is O(n)
	*/
    	private void doubleArray(){
	    	Object[] newArray = new Object[array.length * 2];
		for( int i = 0; i < array.length; i++ )
		    newArray[i] = eval("fe04b0bb-4c97-41ba-9236-233c354ff19d", array[read("array",
"fe04b0bb-4c97-41ba-9236-233c354ff19d",
0,i)],logger.endStatement());
		array = newArray;
    	}
    
    	public int size(){
      	  return currentSize;
    	}

	@Override
	public String toString() {
		String str = "";
		for(int i =0; i < currentSize; i++){
		    str += eval("31f23016-663f-4bf6-86e1-8310c7e01376", array[read("array",
"31f23016-663f-4bf6-86e1-8310c7e01376",
0,i)],0).toString();
		    if(i<currentSize - 1)
		        str += ", ";
		}
		
		return str;
    	}
	
	/*
		INVARIANT
		looks through the heap recursively before and after add, 
		remove and update makes any changes the heap
	*/
    
	/**
	* Internal method for checking the heap order invariant
	* Looks through the heap starting from the root
	*/
	private boolean invariant(){
		return lookThroughHeap(0);
	}
	
	/**
	* Internal method used by the invariant.
	* Recursively looks through the heap, starting from a given index
	* @param index index to start from
	* @return true if the heap order is kept below the given node index
	*/
	public boolean lookThroughHeap(int index){
		int child = index * 2 + 1;
		if(child < currentSize){
			if(!checkChildren(index,child))
				return false;
			else{
				child ++;
				if(child < currentSize)
					return checkChildren(index,child);
				else
					return true;
			}
		}else
			return true;
		
	}
	
	/**
	* Internal method used by the invariant
	* Compares a given child against its parent.
	* If the heap order is kept, it continues checking the heap order below the child.
	* @param parent index of parent
	* @param child index of child
	* @return true if the heap order is kept below the parent
	*/
	private boolean checkChildren(int parent, int child){
		if(comparator.compare(eval("96bcd085-ca50-44ee-a157-ac5b10d3693c", array[read("array",
"96bcd085-ca50-44ee-a157-ac5b10d3693c",
0,parent)],0),eval("fd94e06a-d120-4f9c-871b-b32601c9104a", array[read("array",
"fd94e06a-d120-4f9c-871b-b32601c9104a",
0,child)],0)) <= 0)
			return lookThroughHeap(child);
		else
			return false;
	}

	/**
	* Internal method used by the invariant.
	* prints out the heap.
	*/
	private String showHeap(){
			// TODO: return description of heap contents.
			return toString();
	}
        
        public static void main(String [] args){
            Integer [] integers = new Integer[20];
            for(int i = 0; i < integers.length; i++){
                integers[i] = (int)(Math.random()* 100);
            }
            PrioQueueVisual p = new PrioQueueVisual(new Comparator(){
                @Override
                public int compare(Object elm1, Object elm2) {
                    Integer i1 = (Integer)elm1;
                    Integer i2 = (Integer)elm2;
                    if(i1 < i2){
                        return -1;
                    }
                    if(i1 > i2){
                        return 1;
                    }
                    return 0;
                }
            
            },
            integers);
            
            
logger.printLog();

        }
        
        

public static int read(String name,String statementId, int dimension, int index){ 
logger.loggRead(name, statementId ,index ,dimension);
return index; 
}
public static java.lang.Object write(String name, String statementId, java.lang.Object value){
logger.logWrite(name, statementId, value+"");
return value;
}
public static int eval(String statementId, int value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static String eval(String statementId, String value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static boolean eval(String statementId, boolean value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static char eval(String statementId, char value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static double eval(String statementId, double value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static float eval(String statementId, float value, int statement){
logger.logEval(statementId, value+"");
return value;
}

public static java.lang.Object eval(String statementId, java.lang.Object value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static java.lang.Object[] eval(String statementId, java.lang.Object[] value, int statement){
logger.logEval(statementId, value+"");
return value;
}
public static java.lang.Object[][] eval(String statementId, java.lang.Object[][] value, int statement){
logger.logEval(statementId, value+"");
return value;
}
}
