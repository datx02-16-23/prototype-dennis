/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dennisjonsson.markup;

/**
 *
 * @author dennis
 */
public class AbstractType {
    public static final String ARRAY = "array";
    public static final String ADJECENCY_LIST = "adjacency list";
    public static final String ADJACENCY_MATRIX = "adjacency matrix";
    public static final String BINARY_TREE = "binary tree";
    public static final String UNKNOWN = "unknown";
}
